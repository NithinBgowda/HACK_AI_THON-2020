
import os
import re
import cv2
import numpy as np
from tqdm import tqdm_notebook
import matplotlib.pyplot as plt


col_frames = os.listdir('laneframes/')
col_frames.sort(key=lambda f: int(re.sub('\D', '', f)))

# load frames
col_images=[]

for i in tqdm_notebook(col_frames):
    img = cv2.imread('laneframes/'+i)
    col_images.append(img)


cnt = 0

for img in tqdm_notebook(col_images):
    print(cnt)

    stencil = np.zeros_like(col_images[cnt][:,:,0])

  # apply frame mask
    masked = cv2.bitwise_and(img[:,:,0], img[:,:,0], mask=stencil)

  # apply image thresholding
    ret, thresh = cv2.threshold(masked, 130, 145, cv2.THRESH_BINARY)

  # apply Hough Line Transformation
    lines = cv2.HoughLinesP(thresh, 1, np.pi/180, 30, maxLineGap=200)
    print(lines)
    dmy = img.copy()

  # Plot detected lines
    try:
        print("inside try block")
        for line in lines:
            x1, y1, x2, y2 = line[0]
            cv2.line(dmy, (x1, y1), (x2, y2), (255, 0, 0), 3)

            cv2.imwrite('detectedlanes/'+str(cnt)+'.png',dmy)

    except TypeError:
        cv2.imwrite('detectedlanes/'+str(cnt)+'.png',img)

    cnt+= 1


pathIn= 'detectedlanes/'

# output path to save the video
pathOut = 'roads_v2.mp4'

# specify frames per second
fps = 30.0

from os.path import isfile, join

frame_array = []
files = [f for f in os.listdir(pathIn) if isfile(join(pathIn, f))]
files.sort(key=lambda f: int(re.sub('\D', '', f)))



frame_list = []

for i in tqdm_notebook(range(len(files))):
    filename=pathIn + files[i]
    #reading each files
    img = cv2.imread(filename)
    height, width, layers = img.shape
    size = (width,height)

    #inserting the frames into an image array
    frame_list.append(img)

out = cv2.VideoWriter(pathOut,cv2.VideoWriter_fourcc(*'DIVX'), fps, size)

for i in range(len(frame_list)):
    # writing to a image array
    out.write(frame_list[i])

out.release()
