import os
import re
import cv2 # opencv library
import numpy as np
from os.path import isfile, join
import matplotlib.pyplot as plt


#Importing Video Frames

# get file names of the frames

def startobjectdetection():
    mypath1 = os.path.dirname(os.path.abspath(__file__)).replace('\\', '/') + "/contour_frames_3"
    mypath2 = os.path.dirname(os.path.abspath(__file__)).replace('\\', '/') + "/frames"

    vidObj = cv2.VideoCapture(os.path.dirname(os.path.abspath(__file__)).replace('\\', '/') + "/v2.mp4")
    count =0
    success =1
    while success:
        success, image = vidObj.read()
        print(success)
        if success:
            pass
        else:
            break
        cv2.imwrite(mypath2 +"/"+ str(count)+".png", image)
        count += 1

    col_frames = os.listdir(mypath2+"/")
    print(col_frames)

    # sort file names
    col_frames.sort(key=lambda f: int(re.sub('\D', '', f)))

    # empty list to store the frames
    col_images=[]

    for i in col_frames:
        # read the frames
        img = cv2.imread(mypath2+"/" +i)
        # append the frames to the list
        col_images.append(img)


    # kernel for image dilation
    kernel = np.ones((4,4),np.uint8)

    # font style
    font = cv2.FONT_HERSHEY_SIMPLEX

    # directory to save the ouput frames
    pathIn = mypath2 + "/"


    valid_cntrs = []

    for i in range(len(col_images)-1):

        # frame differencing
        grayA = cv2.cvtColor(col_images[i], cv2.COLOR_BGR2GRAY)
        grayB = cv2.cvtColor(col_images[i+1], cv2.COLOR_BGR2GRAY)
        diff_image = cv2.absdiff(grayB, grayA)

        # image thresholding
        ret, thresh = cv2.threshold(diff_image, 30, 255, cv2.THRESH_BINARY)

        # image dilation
        dilated = cv2.dilate(thresh,kernel,iterations = 1)

        # find contours
        contours, hierarchy = cv2.findContours(dilated.copy(), cv2.RETR_TREE,cv2.CHAIN_APPROX_NONE)

        # shortlist contours appearing in the detection zone
        valid_cntrs = []
        for cntr in contours:
            x,y,w,h = cv2.boundingRect(cntr)
            #if (x <= 200) & (y >= 80) & (cv2.contourArea(cntr) >= 25):
            #    if (y >= 90) & (cv2.contourArea(cntr) < 40):
            #        break
            valid_cntrs.append(cntr)

        # add contours to original frames
        dmy = col_images[i].copy()
        cv2.drawContours(dmy, valid_cntrs, -1, (127,200,0), 2)

        cv2.putText(dmy, "detected objects", (55, 15), font, 0.6, (0, 180, 0), 2)
        cv2.line(dmy, (0, 80),(256,80),(100, 255, 255))
        print("making")
        here = os.path.dirname(os.path.abspath(__file__)).replace('\\', '/') + "/contour_frames_3/" + str(i)+'.png'
        print(here)
        cv2.imwrite(here,dmy)



    # specify video name
    pathOut = 'vehicle_detection_v3.mp4'

    # specify frames per second
    fps = 14.0
    frame_array = []
    files = [f for f in os.listdir(pathIn) if isfile(join(pathIn, f))]
    files.sort(key=lambda f: int(re.sub('\D', '', f)))

    for i in range(len(files)):
        filename=pathIn + files[i]

        #read frames
        img = cv2.imread(filename)
        height, width, layers = img.shape
        size = (width,height)

        #inserting the frames into an image array
        frame_array.append(img)


    out = cv2.VideoWriter(pathOut,cv2.VideoWriter_fourcc(*'DIVX'), fps, size)

    for i in range(len(frame_array)):
        # writing to a image array
        out.write(frame_array[i])

    out.release()
    mypath1 = os.path.dirname(os.path.abspath(__file__)).replace('\\', '/') + "/contour_frames_3"
    mypath2 = os.path.dirname(os.path.abspath(__file__)).replace('\\', '/') + "/frames"
    for root, dirs, files in os.walk(mypath1):
        for file in files:
            print("Deleting")
            os.remove(os.path.join(root, file))
    for root, dirs, files in os.walk(mypath2):
        for file in files:
            print("Deleting")
            os.remove(os.path.join(root, file))




    cap = cv2.VideoCapture(pathOut)
    if (cap.isOpened()== False):
      print("Error opening video  file")

    # Read until video is completed
    while(cap.isOpened()):

      # Capture frame-by-frame
      ret, frame = cap.read()
      if ret == True:

        # Display the resulting frame
        cv2.imshow('Frame', frame)

        # Press Q on keyboard to  exit
        if cv2.waitKey(25) & 0xFF == ord('q'):
          break

      # Break the loop
      else:
        break

    # When everything done, release
    # the video capture object
    cap.release()

    # Closes all the frames
    cv2.destroyAllWindows()
    os.remove(pathOut)
