from django.shortcuts import render
from django.http import HttpResponse,HttpResponseRedirect,HttpRequest,JsonResponse
from django.urls import reverse
from .models import *
import pandas as pd
import numpy as np
import cv2
import os
from .detect import *




def index(request):
    print(Video.objects.all().first())
    print(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    return render(request,'index.html',{})



def detectdynamic(request):
    if request.method == "POST":
        file = request.POST.get('videofile')
        Video.objects.create(file=file)
        startobjectdetection()
    return render(request,'index.html',{})


def videoleaf(request):
    startwebcam()
    return HttpResponse()
